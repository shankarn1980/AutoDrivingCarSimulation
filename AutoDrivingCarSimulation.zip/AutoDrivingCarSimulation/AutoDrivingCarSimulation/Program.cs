﻿using AutoDrivingCarSimulation;
using System;

namespace ConsoleApp2
{
    internal class Program
    {

        static void Main(string[] args)
        {
            string inputLine1,inputLine2,inputLine3 = string.Empty;
            Console.WriteLine("Enter the Width and Height of the field");
            inputLine1=Console.ReadLine() ?? string.Empty;
            if (!inputLine1.Any(Char.IsWhiteSpace))
            {
                Console.WriteLine("Please enter the width and height value with spaces");
                inputLine1 = Console.ReadLine() ?? string.Empty;
            }
             Console.WriteLine("Enter the current position and facing direction of the car");
            inputLine2 = Console.ReadLine() ?? string.Empty;
            Console.WriteLine("Enter the subsequent commands");
            inputLine3 = Console.ReadLine() ?? string.Empty;
            autoDrivingcarSimulation autoDrivingcar = new autoDrivingcarSimulation();
            autoDrivingcar.Output(inputLine1, inputLine2, inputLine3);
           

        }
    }
}