﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoDrivingCarSimulation
{
    public class autoDrivingcarSimulation
    {

        public void Output(string inputLine1, string inputLine2, string inputLine3)

        {
            string[] parts = inputLine2.Split(' ');
            string direction = string.Empty;
            int xposition = Convert.ToInt32(parts[0]);
            int yposition = Convert.ToInt32(parts[1]);
            string inputdirection = parts[2];
            string[] inputLine1split = inputLine1.Split(' ');
            int inputWidth= Convert.ToInt32(inputLine1split[0]);
            int inputHeight= Convert.ToInt32(inputLine1split[1]);
            

            if ((xposition>inputWidth) && (yposition>inputHeight))
            {
                Console.WriteLine("Command is ignored as it is out of the boundary.");
                return;
            }

            if (parts != null)
            {
                foreach (char c in inputLine3)
                {
                    if ((xposition == 0) && (yposition == 0) && (inputdirection == "S") && (c == Convert.ToChar("F")))
                    {
                        Console.WriteLine("Command is ignored as it is out of the boundary.");
                        break;
                    }
                    switch (inputdirection)
                    {
                        case "N":
                            if ((c == Convert.ToChar("L")) && (string.IsNullOrEmpty(direction)))
                            {
                                direction = "W";
                                break;
                            }
                            if ((c == Convert.ToChar("R")) && (string.IsNullOrEmpty(direction)))
                            {
                                direction = "E";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "E"))
                            {
                                direction = "N";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "E"))
                            {
                                direction = "S";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "S"))
                            {
                                direction = "E";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "S"))
                            {
                                direction = "W";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "W"))
                            {
                                direction = "S";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "W"))
                            {
                                direction = "N";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "N"))
                            {
                                direction = "W";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "N"))
                            {
                                direction = "E";
                                break;
                            }

                            if (c == Convert.ToChar("F"))
                            {
                                if (direction == "E")
                                {
                                    xposition = xposition + 1;
                                }
                                else if ((direction == "N") || (string.IsNullOrEmpty(direction)))
                                {
                                    yposition = yposition + 1;
                                }
                                else if (direction == "W")
                                {
                                    xposition = xposition - 1;
                                }
                                else if (direction == "S")
                                {
                                    yposition = yposition - 1;
                                }

                            }
                            break;
                        case "S":
                            if ((c == Convert.ToChar("L")) && (string.IsNullOrEmpty(direction)))
                            {
                                direction = "E";
                                break;
                            }
                            if ((c == Convert.ToChar("R")) && (string.IsNullOrEmpty(direction)))
                            {
                                direction = "W";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "E"))
                            {
                                direction = "N";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "E"))
                            {
                                direction = "S";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "S"))
                            {
                                direction = "E";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "S"))
                            {
                                direction = "W";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "W"))
                            {
                                direction = "S";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "W"))
                            {
                                direction = "N";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "N"))
                            {
                                direction = "W";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "N"))
                            {
                                direction = "E";
                                break;
                            }

                            if (c == Convert.ToChar("F"))
                            {
                                if (direction == "E")
                                {
                                    xposition = xposition + 1;
                                }
                                else if ((direction == "N") || (string.IsNullOrEmpty(direction)))
                                {
                                    yposition = yposition + 1;
                                }
                                else if (direction == "W")
                                {
                                    xposition = xposition - 1;
                                }
                                else if (direction == "S")
                                {
                                    yposition = yposition - 1;
                                }

                            }
                            break;
                        case "E":
                            if ((c == Convert.ToChar("L")) && (string.IsNullOrEmpty(direction)))
                            {
                                direction = "N";
                                break;
                            }
                            if ((c == Convert.ToChar("R")) && (string.IsNullOrEmpty(direction)))
                            {
                                direction = "S";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "E"))
                            {
                                direction = "N";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "E"))
                            {
                                direction = "S";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "S"))
                            {
                                direction = "E";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "S"))
                            {
                                direction = "W";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "W"))
                            {
                                direction = "S";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "W"))
                            {
                                direction = "N";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "N"))
                            {
                                direction = "W";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "N"))
                            {
                                direction = "E";
                                break;
                            }

                            if (c == Convert.ToChar("F"))
                            {
                                if (direction == "E")
                                {
                                    xposition = xposition + 1;
                                }
                                else if ((direction == "N") || (string.IsNullOrEmpty(direction)))
                                {
                                    yposition = yposition + 1;
                                }
                                else if (direction == "W")
                                {
                                    xposition = xposition - 1;
                                }
                                else if (direction == "S")
                                {
                                    yposition = yposition - 1;
                                }

                            }
                            break;

                        case "W":
                            if ((c == Convert.ToChar("L")) && (string.IsNullOrEmpty(direction)))
                            {
                                direction = "S";
                                break;
                            }
                            if ((c == Convert.ToChar("R")) && (string.IsNullOrEmpty(direction)))
                            {
                                direction = "N";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "E"))
                            {
                                direction = "N";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "E"))
                            {
                                direction = "S";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "S"))
                            {
                                direction = "E";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "S"))
                            {
                                direction = "W";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "W"))
                            {
                                direction = "S";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "W"))
                            {
                                direction = "N";
                                break;
                            }

                            if ((c == Convert.ToChar("L")) && (direction == "N"))
                            {
                                direction = "W";
                                break;
                            }

                            if ((c == Convert.ToChar("R")) && (direction == "N"))
                            {
                                direction = "E";
                                break;
                            }

                            if (c == Convert.ToChar("F"))
                            {
                                if (direction == "E")
                                {
                                    xposition = xposition + 1;
                                }
                                else if ((direction == "N") || (string.IsNullOrEmpty(direction)))
                                {
                                    yposition = yposition + 1;
                                }
                                else if (direction == "W")
                                {
                                    xposition = xposition - 1;
                                }
                                else if (direction == "S")
                                {
                                    yposition = yposition - 1;
                                }

                            }
                            break;

                    }

                }
                Console.WriteLine(xposition + " " + yposition + " " + direction);
            }
        }
    }
}
